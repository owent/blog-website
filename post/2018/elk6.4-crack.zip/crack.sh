#!/bin/bash

export PATH=$PATH:/sbin;

if [ $# -lt 1 ]; then
    echo "Usage: $0 <ip>";
    exit 1;
fi

BIND_IP=$1;

SCRIPT_DIR="$(cd $(dirname $0) && pwd)";
source "$SCRIPT_DIR/deploy-conf.sh";
CRACK_JAR_NAME=x-pack-core-6.4.2;

/etc/init.d/elasticsearch stop ;

cd "$ELK_HOME_DIR";
if [ -e "$SCRIPT_DIR/crack/$CRACK_JAR_NAME.crack.jar" ]; then
    if [ ! -e "$ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar.bak" ]; then
        mv "$ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar" "$ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar.bak";
    fi
    cp -f "$SCRIPT_DIR/crack/$CRACK_JAR_NAME.crack.jar" "$ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar";
    chown $USER:$GROUP -R "$ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar"; 
    echo "md5: $(md5sum -b $ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar)";
    echo "sha1: $(sha1sum -b $ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar)";
    echo "sha256: $(sha256sum -b $ELK_ELASTICSEARCH_PKG_NAME/modules/x-pack-core/$CRACK_JAR_NAME.jar)";
fi


/etc/init.d/elasticsearch start ;
wait_for_elasticsearch_startup;

# ====================== check license ======================
echo "curl -u elastic:$ELK_CLUSTER_PASSWORD 'http://$BIND_IP:$ELK_ELASTICSEARCH_PORT/_xpack?pretty'";
curl -u elastic:$ELK_CLUSTER_PASSWORD "http://$BIND_IP:$ELK_ELASTICSEARCH_PORT/_xpack?pretty";
echo "curl -u elastic:$ELK_CLUSTER_PASSWORD 'http://$BIND_IP:$ELK_ELASTICSEARCH_PORT/_xpack/license?pretty'";
curl -u elastic:$ELK_CLUSTER_PASSWORD "http://$BIND_IP:$ELK_ELASTICSEARCH_PORT/_xpack/license?pretty";
