
# X-package 6.4.X 破解

## 获取x-pack-core-6.4.X.jar

## 下载 elasticsearch
下载页面：https://www.elastic.co/downloads/elasticsearch

下载下来，解压压缩包，x-pack-core-6.4.X.jar 就位于 elasticsearch-6.4.X/modules/x-pack-core 目录下面
使用luyten反编译x-pack-core-6.4.X.jar

## 下载 luyten
下载页面：https://github.com/deathmarine/Luyten/releases

软件下载下来，打开软件，把x-pack-core-6.4.X.jar 丢进去，就能看到我们jar包的源代码了。
我们需要把2个文件提取出来进行修改。

org.elasticsearch.license.LicenseVerifier

org.elasticsearch.xpack.core.XPackBuild

## 1、修改LicenseVerifier
LicenseVerifier 中有两个静态方法，这就是验证授权文件是否有效的方法，我们把它修改为全部返回true.

```java
package org.elasticsearch.license;

import java.nio.*;
import org.elasticsearch.common.bytes.*;
import java.util.*;
import java.security.*;
import org.elasticsearch.common.xcontent.*;
import org.apache.lucene.util.*;
import org.elasticsearch.core.internal.io.*;
import java.io.*;

public class LicenseVerifier
{
    public static boolean verifyLicense(final License license, final byte[] encryptedPublicKeyData) {
        return true;
    }

    public static boolean verifyLicense(final License license) {
        return true;
    }
}
```

## 2、修改XPackBuild

```java
XPackBuild 中最后一个静态代码块中 try的部分全部删除，这部分会验证jar包是否被修改.

package org.elasticsearch.xpack.core;

import org.elasticsearch.common.io.*;
import java.net.*;
import org.elasticsearch.common.*;
import java.nio.file.*;
import java.io.*;
import java.util.jar.*;

public class XPackBuild
{
    public static final XPackBuild CURRENT;
    private String shortHash;
    private String date;

    @SuppressForbidden(reason = "looks up path of xpack.jar directly")
    static Path getElasticsearchCodebase() {
        final URL url = XPackBuild.class.getProtectionDomain().getCodeSource().getLocation();
        try {
            return PathUtils.get(url.toURI());
        }
        catch (URISyntaxException bogus) {
            throw new RuntimeException(bogus);
        }
    }

    XPackBuild(final String shortHash, final String date) {
        this.shortHash = shortHash;
        this.date = date;
    }

    public String shortHash() {
        return this.shortHash;
    }

    public String date() {
        return this.date;
    }

    static {
        final Path path = getElasticsearchCodebase();
        String shortHash = null;
        String date = null;
        Label_0157: {
            shortHash = "Unknown";
            date = "Unknown";
        }
        CURRENT = new XPackBuild(shortHash, date);
    }
}
```

## 编译修改后的java文件

```bash
javac -cp ".:./x-pack-core-6.3.2.jar:./elasticsearch-6.4.X/lib/*" LicenseVerifier.java
javac -cp ".:./x-pack-core-6.3.2.jar:./elasticsearch-6.4.X/lib/*" XPackBuild.java
```

需要注意的是，编译这两个文件的时候 需要指定依赖包的位置 如果你的位置和我的有区别，注意修改。
将编译好的class文件重新压回x-pack-core-6.4.X.jar

解压x-pack-core-6.4.X.jar 会得到一个 x-pack-core-6.4.X目录，按照其位置将编译好的2个 class文件放到我们目录里面，替换老的。

## 将修改过的 x-pack-core-6.4.X目录重新压成jar包。
https://stackoverflow.com/questions/18146361/how-to-create-jar-file-with-package-structure

```bash
jar -cvf x-pack-core-6.4.X_new.jar -C x-pack-core-6.4.X .
```

## 导入授权文件

1、 先从官网申请basic授权文件
https://license.elastic.co/registration

2、 授权文件修改

```json
{

   "uid": "6fb96d6b-938c-45ff-9ce7-6b53b39cd7dd",

   "type": "platinum", # 修改授权为白金版本

   "issue_date_in_millis": 1530489600000,

   "expiry_date_in_millis": 2855980923000, #修改到期时间为2060-07-02

   "max_nodes": 100,  # 修改最大节点数

   "issued_to": "xxxx",

   "issuer": "Web Form",

   "signature":"AAAAAwAAAA3PP60wKNtAvRmuCGdSAAABmC9ZN0hjZDBGYnVyRXpCOW5Bb3FjZDAxOWpSbTVoMVZwUzRxVk1PSmkxaktJRVl5MUYvUWh3bHZVUTllbXNPbzBUemtnbWpBbmlWRmRZb25KNFlBR2x0TXc2K2p1Y1VtMG1UQU9TRGZVSGRwaEJGUjE3bXd3LzRqZ05iLzRteWFNekdxRGpIYlFwYkJiNUs0U1hTVlJKNVlXekMrSlVUdFIvV0FNeWdOYnlESDc3MWhlY3hSQmdKSjJ2ZTcvYlBFOHhPQlV3ZHdDQ0tHcG5uOElCaDJ4K1hob29xSG85N0kvTWV3THhlQk9NL01V",

   "start_date_in_millis": 1530489600000

}
```

## 时间戳、时间转换

https://tool.lu/timestamp

## 3.通过API接口上传

```bash
curl -u elastic:elastic -XPUT ‘http://es-ip:port/_xpack/license’ -H “Content-Type: application/json” -d @/tmp/license.json
```
