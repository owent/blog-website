#!/bin/bash

if [ $# -lt 1 ]; then
    echo "Usage: $0 <ip>";
    exit 1;
fi

REMOTE_IP=$1;
CRACK_JAR_NAME=x-pack-core-6.4.2;

ssh owentou@$REMOTE_IP -p 36000 "echo \"PWD=\$PWD\" && echo \"HOME=\$HOME\" && mkdir -p \$HOME/elk/crack";
scp -P 36000 crack/$CRACK_JAR_NAME.crack.jar "owentou@$REMOTE_IP:/data/home/owentou/elk/crack/$CRACK_JAR_NAME.crack.jar";
scp -P 36000 *.sh "owentou@$REMOTE_IP:/data/home/owentou/elk/";

ssh owentou@$REMOTE_IP -p 36000 "echo \"PWD=\$PWD\" && echo \"HOME=\$HOME\" && cd \$HOME/elk && chmod +x *.sh && sudo ./crack.sh $REMOTE_IP";